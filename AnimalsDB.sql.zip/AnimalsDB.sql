-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Dec 05, 2018 at 12:45 AM
-- Server version: 5.6.38
-- PHP Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `AnimalsDB`
--
CREATE DATABASE IF NOT EXISTS `AnimalsDB` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `AnimalsDB`;

-- --------------------------------------------------------

--
-- Table structure for table `AnimalList`
--

CREATE TABLE `AnimalList` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `sex` varchar(1) NOT NULL,
  `dateofadmittance` date NOT NULL,
  `breed` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `CatBreed`
--

CREATE TABLE `CatBreed` (
  `id` int(11) NOT NULL,
  `CatBreed` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `CatBreed`
--

INSERT INTO `CatBreed` (`id`, `CatBreed`) VALUES
(1, 'Exotic Shorthair'),
(2, 'Persian'),
(3, 'Scottish Fold'),
(4, 'Maine Coon'),
(5, 'Ragdoll'),
(6, 'British Shorthair'),
(7, 'American Shorthair'),
(8, 'Abyssinian'),
(9, 'Sphynx'),
(10, 'Siamese');

-- --------------------------------------------------------

--
-- Table structure for table `DogBreed`
--

CREATE TABLE `DogBreed` (
  `id` int(11) NOT NULL,
  `dogbreed` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `DogBreed`
--

INSERT INTO `DogBreed` (`id`, `dogbreed`) VALUES
(1, 'Labrador'),
(2, 'German Shorthaired Pointer'),
(3, 'German Shepherd'),
(4, 'Golden Retriever'),
(5, 'French Bulldog'),
(6, 'Bulldog'),
(7, 'Beagle'),
(8, 'Poodle'),
(9, 'Rottweiler'),
(10, 'Yorkshire Terrier');

-- --------------------------------------------------------

--
-- Table structure for table `RabbitBreed`
--

CREATE TABLE `RabbitBreed` (
  `id` int(11) NOT NULL,
  `RabbitBreed` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `RabbitBreed`
--

INSERT INTO `RabbitBreed` (`id`, `RabbitBreed`) VALUES
(1, 'American Fuzzy Lop'),
(2, 'Britannia Petite'),
(3, 'Dutch'),
(4, 'Dwarf Hotot'),
(5, 'Havana'),
(6, 'Himalayan'),
(7, 'Holland Lop');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `AnimalList`
--
ALTER TABLE `AnimalList`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `CatBreed`
--
ALTER TABLE `CatBreed`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `DogBreed`
--
ALTER TABLE `DogBreed`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `RabbitBreed`
--
ALTER TABLE `RabbitBreed`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `AnimalList`
--
ALTER TABLE `AnimalList`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `CatBreed`
--
ALTER TABLE `CatBreed`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `DogBreed`
--
ALTER TABLE `DogBreed`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `RabbitBreed`
--
ALTER TABLE `RabbitBreed`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
